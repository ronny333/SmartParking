iOS-Table-View-tutorial-using-swift
===================================

The Main objective of this blog is how to make a simple table view &amp; understanding about UITableView Delegate and DataSource in Swift programming language in iOS.

You can find complete tutorial on how to use this code repo here : <a href="http://www.theappguruz.com/blog/ios-table-view-tutorial-using-swift">iOS Table View tutorial using swift</a>

This Tutorial has been presented by The App Guruz - One of the best <a href="http://www.theappguruz.com/mobile-application-development/">Mobile Application Development</a>
